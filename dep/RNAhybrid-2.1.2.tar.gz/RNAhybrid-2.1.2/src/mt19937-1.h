#ifdef __cplusplus
extern "C" {
#endif

void sgenrand(unsigned long seed);

double genrand();


#ifdef __cplusplus
}
#endif
